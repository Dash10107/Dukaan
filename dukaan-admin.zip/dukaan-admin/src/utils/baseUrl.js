export const base_url = "https://digic-backend.vercel.app/api/";
